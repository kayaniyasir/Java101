package application;
public class Practice12 {
    public static void main(String[] args) {
        int a , b , c, d ;
        a = b= c= d = 2;
        int k = 0; // = assignment 
        int i = k + 2;
        System.out.println(i);
    }
    
}
