package application;
import java.util.Scanner;
public class ConvertP2KG {
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        double kg,lb;
        System.out.println(" Enter the pounds ");
        lb = input.nextDouble();
        kg = lb / 2.2046;
        System.out.println(lb +" lb = "+ kg+" kg");
    }
    
}
