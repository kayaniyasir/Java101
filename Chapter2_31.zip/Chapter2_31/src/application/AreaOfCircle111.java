package application;
import java.util.*;
public class AreaOfCircle111 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double radius;
        //double PI = 3.1415; 
        System.out.println("Enter the radius of Circle: ");
        radius = input.nextDouble();
        double areaCircle = Math.PI * Math.pow(radius, 2) ;
        System.out.println("The area is "+ areaCircle);
    }
    
}
