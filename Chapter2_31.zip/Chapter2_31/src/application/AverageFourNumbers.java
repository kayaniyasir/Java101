package application;
import java.util.Scanner;
public class AverageFourNumbers {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double num1, num2, num3, num4, avg;
 
        System.out.println("Enter four numbers : ");
            num1 = input.nextDouble();
            num2 = input.nextDouble();
            num3 = input.nextDouble();
            num4 = input.nextDouble();
        avg = ( num1 + num2 + num3 + num4 ) / 4;
        System.out.println("The average is "+ avg);
        
    }
    
}
