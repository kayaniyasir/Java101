package application;
import java.awt.Toolkit;
import java.util.Scanner;
public class VelocitySpeed {
    public static void main(String[] args) {
        /*----------- Varibales ----------------*/
        Scanner myInput = new Scanner(System.in);//1. Scanner
        double v, xi, xf, dx, t; // 2. all varibales
        /*------------- Inputs ------------------ */
       Toolkit.getDefaultToolkit().beep();
        System.out.print("Please enter inital and final position : ");
        xi = myInput.nextDouble();
        xf = myInput.nextDouble();
        Toolkit.getDefaultToolkit().beep();
        System.out.print("Enter the time : ");
        t = myInput.nextDouble();
        /*--------------- Calulcations ------------------*/
        dx = xf-xi;
        v = dx/t;
        /************* OUTPUT ************************/
        System.out.println("\n\tThe velocity is "+ v +" m/sec\n");
    }
}
