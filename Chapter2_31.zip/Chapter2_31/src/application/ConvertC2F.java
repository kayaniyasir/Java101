package application;
import java.util.Scanner;
public class ConvertC2F {
    public static void main(String[] args) {
        //T(°F) = T(°C) × 1.8 + 32
        Scanner input = new Scanner(System.in);
        double celsius, farenheit;
        System.out.print("Enter the temprature in Celsius : ");
        celsius = input.nextDouble();
       farenheit = celsius * 1.8 + 32;
        System.out.println(celsius +"°C = "+ farenheit + " °F");
    }
    
}
