package application;
import java.util.*;
public class AreaOfCircle {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double radius;
        double PI = 3.1415; 
            System.out.println("Enter the radius of Circle: ");
            radius = input.nextDouble();
        double areaCircle = PI * radius * radius ;
        System.out.println("The area is "+ areaCircle);
    }
    
}
