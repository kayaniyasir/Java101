package application;
import java.util.Scanner;
public class MyFirstConstantClass {
    public static void main(String[] args) {
        Scanner myScan = new Scanner(System.in);
         int height, radius;
         double areaCone;
         final double MY_PI = 3.1415;
         final int SIZE = 20;
        System.out.print("Enter the height and radius : ");
         height = myScan.nextInt();
         radius = myScan.nextInt();
    double temp = Math.pow(height, 2)+Math.pow(radius, 2);
    double temp1 = Math.sqrt(temp);
    double temp2 = radius + temp1;
    double temp3 = MY_PI * radius;
            areaCone = temp2 * temp3;
    System.out.println("The area of COne is "+ areaCone);
    }
    
}
