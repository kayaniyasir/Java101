package chapter2_31;
import java.util.Scanner;
public class Chapter2_31 {
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
       String name;
       double marks;
        System.out.println("Enter your name : ");
        name = input.next();
        System.out.println("Enter the marks : ");
        marks = input.nextDouble();
        System.out.println(name +" your marks are "+ marks);
        System.out.println(name.length());
    }
    
}
