
public class NewClass23 {
    public static void main(String[] args) {
        byte a = 125;
        byte b = 4;
        byte c = (byte) (a +b);
        System.out.println(""+c);
    }
    
}
