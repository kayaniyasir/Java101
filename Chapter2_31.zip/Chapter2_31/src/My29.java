public class My29 {
public static void main(String[] args) {
   double miles = 100;
   final double KILOMETERS_PER_MILE = 1.609;
   double kilometers = miles * KILOMETERS_PER_MILE; 
    System.out.println("Kilometers : "+ kilometers);
    System.out.println(2 * (5.0 / 2 + 5 / 2));
    System.out.println(2 * 5 / 2); // ()*/+-
    System.out.println(2 * 5 / 2 + 2 * 5 / 2);
    System.out.println("25 / 4 is " + 25.0 / 4);
    System.out.println("3 * 2 / 4 is " + 3 * 2 / 4);
    System.out.println(Math.pow(2, 3.5                                                                                                                                                                         ));
int m,r;
m = r =5;
double result = m* Math.pow(r,2);
}
}
